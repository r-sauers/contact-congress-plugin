# Contact Congress Plugin

**Contributors:** rsauers \
**Donate link:** http://example.com/ \
**Tags:** comments, spam \
**Requires at least:** 3.0.1 \
**Tested up to:** 3.4 \
**Stable tag:** 4.3 \
**License:** GPLv2 or later \
**License URI:** http://www.gnu.org/licenses/gpl-2.0.html

A plugin for visitors of your site to contact members of congress with pre-filled emails.

## Description

A plugin for visitors of your site to contact members of congress with pre-filled emails.

Features a block on the wordpress page editor that can be easily dragged and dropped.

## Installation

To install and use the plugin:
1. download `congress.zip`
1. log in as admin to your wordpress site
1. upload it in the plugins page
1. activate the plugin

There are no currently supported hooks.
If you are looking to set up wordpress, I recommend going to Contributing.md

## Frequently Asked Questions

### Can I help contribute?

Yes! Please go to github and lookat Contributing.md!

## Screenshots

### 1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from

[missing image]

the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).

## Changelog

### 0.0.0

* Created a block

## Upgrade Notice

### 1.0

Upgrade to 1.0 for a functional plugin
