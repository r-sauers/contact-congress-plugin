<?php
/**
 * Silence is golden.
 *
 * @package Congress
 * **/
